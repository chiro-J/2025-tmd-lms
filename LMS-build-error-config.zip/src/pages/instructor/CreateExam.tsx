import QuestionManagement from './QuestionManagement'

export default function CreateExam() {
  // 완전 대체: 생성 페이지에서 곧바로 문제 관리 화면을 사용
  return <QuestionManagement />
}
