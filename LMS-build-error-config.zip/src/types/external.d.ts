declare module '@fontsource/nanum-gothic';


